clear all

%%% Define constants %%%
u_0 = 4*pi*10^-7;
c = 299792458;

q_0 = 5*10^-6; % 5 microcoulombs
d = 1*10^-3; % 1mm
r = 2.0; % 2m

p_0 = q_0*d;
omega = 50*(2*pi); % 50 cycles per second

n = 50;

theta = linspace(0,pi,n);
phi = linspace(0,2*pi,n);
[theta,phi] = meshgrid(theta,phi);

I = ((u_0*p_0^2*omega.^4)/(32*pi^2*c*r^2))*(sin(theta))^2;
x = [sin(theta).*cos(theta) sin(theta).*sin(phi) cos(theta)]; % r
y = [cos(theta).*cos(phi) cos(theta).*sin(phi) -sin(theta)];
z = [-1*sin(theta) cos(theta) zeros(size(sin(theta)))];

surf(x,y,z)
xlabel('x')
ylabel('y')
zlabel('z')