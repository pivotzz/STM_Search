%clear all;clc

A = imread(file);
A = rgb2hsv(A); 
%A = imgaussfilt(A,2.5); imshow(A)

H = A(:,:,1); 
S = A(:,:,2); 
V = A(:,:,3);

%%% Lighten everywhere else and gray selected pixels
V(:,:) = 4 ;
for a = 1:size(row)
    V(row(a),col(a)) = 0.5;
end
%imshow(V);

%%% Perform edge detection
BW = edge(V);

% Thicken and the pixels and fill
se90 = strel('line',3,90);
se0 = strel('line',3,0);
BWdil = imdilate(BW,[se90 se0]);
BWdfill = imfill(BWdil,'holes');

% to remove objects on border
BWnobord = imclearborder(BWdfill,4); 

seD = strel('diamond',2);
BWfinal = imerode(BWnobord,seD);
BWfinal = imerode(BWfinal,seD);
figure(2); imshow(BWfinal);
hold on

%%% Categorizing the Areas
L = bwlabel(BWfinal);
M = max(L,[],'all');
row1 = zeros(sum(L(:) ~= 0),1); col1 = row1;
save_row = 1;
for num1 = 1:M
    size_current = size(find(L == num1));
    size_current = size_current(1);
    [row1(save_row:save_row + size_current - 1), col1(save_row:save_row + size_current - 1)] = find(L == num1);
    save_row = save_row + size_current;
end

Area1 = [row1 col1];
Area2 = zeros(M,3);
save_num = 1;
for num2 = 1:M
    Area2(num2,1) = sum(L(:) == num2);
    Area2(num2,2) = Area1(save_num,1);
    Area2(num2,3) = Area1(save_num,2);
    save_num = save_num + sum(L(:) == num2);
end
    
   
%%% Corner Detection
corners = detectHarrisFeatures(BWfinal);
plot(corners);
C = corner(BWfinal,'r');
plot(C(:,1),C(:,2),'r*');

A = imread(file);
imshow(labeloverlay(A,BWdfill))
numofpixels = sum(BWfinal(:) == 1);

%%% Find initial point on each boundary
dim = size(BWfinal);

% find coordinates of edge of sample
[row1,col1] = find(BWfinal);

%%%% Invert color for line detection
BWfinal = ~BWfinal;
imshow(BWfinal);
contour = bwtraceboundary(BWfinal,[row1(1) col1(1)],'N');
plot(contour(:,2),contour(:,1),'r','LineWidth',2)


        
        
        















