clear all; close all

%%% Define constants %%%
u_0 = 4*pi*10^-7;
c = 299792458;

q_0 = 5*10^-6; % 5 microcoulombs
d = 1*10^-3; % 1mm
r = 2.0; % 2m

p_0 = q_0*d;
omega = 50*(2*pi); % 50 cycles per second

n = 50;
%zeros_theta = zeros(1,n/2);
%half_theta = linspace(pi/2,pi,n/2);
%theta = [zeros_theta half_theta];
theta = linspace(0,pi,n);
phi = linspace(0,2*pi,n);
[theta,phi] = meshgrid(theta,phi);
I = ((u_0*p_0^2*omega^4)/(32*pi^2*c*r^2))*(sin(theta)).^2;
x = I.*sin(theta).*cos(phi); 
y = I.*sin(theta).*sin(phi);  
z = I.*cos(theta);
z(:,1:25) = 0;
%x = x(:,25:50);
%y = y(:,25:50);
%z = z(:,25:50);
C = sqrt(x.^2 + y.^2 + z.^2);

s = surf(x,y,z,C);
hold on
%s.CDataSource = 'C';
%refreshdata

xlabel('x')
ylabel('y')
zlabel('z')
