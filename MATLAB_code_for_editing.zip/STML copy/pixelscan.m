clear all;close all;clc
file = 'original.jpg';
A = imread(file);

%%% RGB values of image
R = A(:,:,1); 
G = A(:,:,2); 
B = A(:,:,3);

%%% Input RBG values we are searching 
r_value = 25;
g_value = 90;
b_value = 83;
search_value = [r_value;g_value;b_value];

%%% Upper and lower limit of the range
r_var = 16;
g_var = 11; 
b_var = 11; 

%%% Return location of selected values 
location = (R>=r_value-r_var) & (R<=r_value+r_var) & (G>=g_value-g_var) & (G<=g_value+g_var) & (B>=b_value-b_var) & (B<=b_value+b_var);
figure(2); imshow(location); set(figure(2),'WindowStyle','docked')
imshow(labeloverlay(A,location))

%%% Convert location into compiled list of row and column values 
[row,col] = find(location);
detected_location = [row col];

%angle_detect2
grayer_and_edge













