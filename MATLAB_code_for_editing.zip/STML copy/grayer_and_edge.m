%clear all;clc

A = imread(file);
A = rgb2hsv(A); 
%A = imgaussfilt(A,2.5); imshow(A)

H = A(:,:,1); 
S = A(:,:,2); 
V = A(:,:,3);

%%% Lighten everywhere else and gray selected pixels
V(:,:) = 4 ;
for a = 1:size(row)
    V(row(a),col(a)) = 0.5;
end
imshow(V);

%%% Perform edge detection
BW = edge(V);

% Thicken and the pixels and fill
se90 = strel('line',3,90);
se0 = strel('line',3,0);
BWdil = imdilate(BW,[se90 se0]);
BWdfill = imfill(BWdil,'holes');

% to remove objects on border
BWnobord = imclearborder(BWdfill,4); 

seD = strel('diamond',2);
BWfinal = imerode(BWnobord,seD);
BWfinal = imerode(BWfinal,seD);
imshow(BWfinal);
A = imread(file);
imshow(A)
hold on

%%% Corner Detection
%corners = detectHarrisFeatures(BWfinal);
%plot(corners);
%C = corner(BWfinal);
%plot(C(:,1),C(:,2),'r*');

%A = imread(file);
%imshow(labeloverlay(A,BWdfill))
%numofpixels = sum(BWfinal(:) == 1); 

%%% Find initial point on each boundary
dim = size(BWfinal);
% find coordinates of edge of sample
[row1,col1] = find(BWfinal);
row2 = sort(row1);
col2 = sort(col1);

row_mean = round((max(row2)+min(row2))/2);
col_mean = round((max(col2)+min(col2))/2);

row_find = find(row1 == row_mean);
col_find = find(col1 == col_mean);

% left side
col_right = col1(row_find(1));
row_right = row_mean;

% bottom side
col_top = col_mean;
row_top = row1(col_find(end));

%%%% Invert color for line detection
%BWfinal = ~BWfinal;
%imshow(BWfinal);

line1 = bwtraceboundary(BWfinal,[row_right col_right],'W',8,33,'counterclockwise');
line2 = bwtraceboundary(BWfinal,[row_top col_top],'SW',8,22,'clockwise');
hold on
plot(line1(:,2),line1(:,1),'g','LineWidth',2);
plot(line2(:,2),line2(:,1),'g','LineWidth',2);

ab1 = polyfit(line1(:,2), line1(:,1), 1);
ab2 = polyfit(line2(:,2), line2(:,1), 1);

vect1 = [1 ab1(1)]; % create a vector based on the line equation
vect2 = [1 ab2(1)];
dp = dot(vect1, vect2);

% compute vector lengths
length1 = sqrt(sum(vect1.^2));
length2 = sqrt(sum(vect2.^2));

% obtain the larger angle of intersection in degrees
angle = acos(dp/(length1*length2))*180/pi

intersection = [1 ,-ab1(1); 1, -ab2(1)] \ [ab1(2); ab2(2)];
% apply offsets in order to compute the location in the original,
% i.e. not cropped, image.

inter_x = intersection(2);
inter_y = intersection(1);

% draw an "X" at the point of intersection
plot(inter_x,inter_y,'yx','LineWidth',2);

text(inter_x-35, inter_y+5, [sprintf('%1.3f',angle),'{\circ}'],...
     'Color','y','FontSize',14,'FontWeight','bold');

interString = sprintf('(%2.1f,%2.1f)', inter_x, inter_y);

%text(inter_x-10, inter_y+20, interString,...
     %'Color','r','FontSize',14,'FontWeight','bold');

