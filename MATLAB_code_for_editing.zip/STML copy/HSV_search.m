clear all; close all; clc
A = imread('original.jpg');

%%% Convert RGB to HSV %%%
A = rgb2hsv(A);

%%% Input HSV values %%%
H = A(:,:,1); 
S = A(:,:,2); 
V = A(:,:,3);

%%% HSV Values searcher %%%
figure(2); image(A)
[col,row] = ginput;
row = round(row);
col = round(col);
hsv_rows = size(row);
hsv_values = zeros(hsv_rows(1),3);

for ii = 1:size(row)
    hsv_values(ii,:) = [H(row(ii),col(ii)) S(row(ii),col(ii)) V(row(ii),col(ii))];
end

%%% Find the average, max, min and standard deviation %%%
hsv_mean = mean(hsv_values)
hsv_largest = max(hsv_values)
hsv_smallest = min(hsv_values)
hsv_std = std(hsv_values)
