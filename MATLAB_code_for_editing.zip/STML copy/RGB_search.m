clear all; close all; clc
A = imread('original.jpg');

%A = imgaussfilt(A,4);
R = A(:,:,1); 
G = A(:,:,2); 
B = A(:,:,3);

%R = medfilt2(R);
%G = medfilt2(G);
%B = medfilt2(B);
%A(:,:,1) = R;
%A(:,:,2) = G;
%A(:,:,3) = B;

figure(2); image(A)
[col,row] = ginput;
row = round(row);
col = round(col);
rgb_rows = size(row);
rgb_values = zeros(rgb_rows(1),3);

for ii = 1:size(row)
    rgb_values(ii,:) = [R(row(ii),col(ii)) G(row(ii),col(ii)) B(row(ii),col(ii))];
end

rgb_mean = mean(rgb_values);
rgb_largest = max(rgb_values);
rgb_smallest = min(rgb_values);
rgb_std = std(rgb_values);