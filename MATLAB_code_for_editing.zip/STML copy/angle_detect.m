%clear all;clc

A = imread(file);
A = rgb2hsv(A); 
%A = imgaussfilt(A,2.5); imshow(A)

H = A(:,:,1); 
S = A(:,:,2); 
V = A(:,:,3);

%%% Lighten everywhere else and gray selected pixels
V(:,:) = 4 ;
for a = 1:size(row)
    V(row(a),col(a)) = 0.5;
end
%imshow(V);

%%% Perform edge detection
BW = edge(V);

% Thicken and the pixels and fill
se90 = strel('line',3,90);
se0 = strel('line',3,0);
BWdil = imdilate(BW,[se90 se0]);
BWdfill = imfill(BWdil,'holes');

% to remove objects on border
BWnobord = imclearborder(BWdfill,4); 

seD = strel('diamond',2);
BWfinal = imerode(BWnobord,seD);
BWfinal = imerode(BWfinal,seD);
figure(2); imshow(BWfinal);
hold on

%%% Categorizing the Areas
L = bwlabel(BWfinal);
M = max(L,[],'all');
row1 = zeros(sum(L(:) ~= 0),1); col1 = row1;
save_row = 1;
for num1 = 1:M
    size_current = size(find(L == num1));
    size_current = size_current(1);
    [row1(save_row:save_row + size_current - 1), col1(save_row:save_row + size_current - 1)] = find(L == num1);
    save_row = save_row + size_current;
end

Area1 = [row1 col1];
Area2 = zeros(M,3);
save_num = 1;
for num2 = 1:M
    Area2(num2,1) = sum(L(:) == num2);
    Area2(num2,2) = Area1(save_num,1);
    Area2(num2,3) = Area1(save_num,2);
    save_num = save_num + sum(L(:) == num2);
end
    
   
%%% Corner Detection
corners = detectHarrisFeatures(BWfinal);
%plot(corners);
%C = corner(BWfinal,'r');
%plot(C(:,1),C(:,2),'r*');

%A = imread(file);
%imshow(labeloverlay(A,BWdfill))
numofpixels = sum(BWfinal(:) == 1);

%%% Find initial point on each boundary
%dim = size(BWfinal);

% find coordinates of edge of sample
%[row1,col1] = find(BWfinal);

%%%% Invert color for line detection
%BWfinal = ~BWfinal;
%imshow(BWfinal);
%contour = bwtraceboundary(BWfinal,[row1(1) col1(1)],'N');
%plot(contour(:,2),contour(:,1),'r','LineWidth',2)

%%% Run 'for' loop for every 2 corner point, determine angle between
%%% subsequent lines
corner_loc = corners.Location;
x = corner_loc(:,1); y = corner_loc(:,2);
cx = mean(x);
cy = mean(y);
a = atan2(y - cy, x - cx);
[~, order] = sort(a);
x = x(order);
y = y(order);
corner_loc = [x y];
[xx ~] = size(corner_loc);
plot(corner_loc(:,1),corner_loc(:,2),'r*');
corner_loc(xx+1,:) = corner_loc(1,:);

grads = zeros(xx,1);
for row = 1:xx
    points = 2;
    line1 = zeros(points,2);
    line1(:,1) = [corner_loc(row,1) corner_loc(row+1,1)]; % x-coordinate
    line1(:,2) = [corner_loc(row,2) corner_loc(row+1,2)]; % y-coordinate
    x1 = line1(:,1); y1 = line1(:,2);
    coefficients = polyfit(x1,y1,1);
    
    grads(row,1) = coefficients(1);
    plot(x1,y1,'b','LineWidth',3);
end
grads(xx+1) = grads(1);
sides = 0;
for num = 1:xx
    per_diff1 = abs(grads(num)-grads(num+1))/abs(grads(num));
    per_diff2 = abs(grads(num)-grads(num+1))/abs(grads(num+1));
    if per_diff1 > 3
        sides = sides + 1;
    elseif per_diff2 > 3
        sides = sides + 1;
    end
end
    
        
        
        















